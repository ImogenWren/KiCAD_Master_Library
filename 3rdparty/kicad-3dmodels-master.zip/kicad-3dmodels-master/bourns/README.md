# kicad-3dmodels

Bourns Multi turn Trim Potentiometers:
![Bourns Multi turn Trim Potentiometers](https://github.com/dhaillant/kicad-3dmodels/raw/master/bourns/bourns.png)

Based on [Bourns Datasheet](http://www.bourns.com/docs/product-datasheets/3296.pdf)
