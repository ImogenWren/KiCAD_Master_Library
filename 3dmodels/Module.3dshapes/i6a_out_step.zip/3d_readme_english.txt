Cautions When Using 3D Shape Data

1. Copyright, ownership
TDK-Lambda retains the copyright and all other rights to this 3D shape data.

2. Duplication / distribution prohibition
This 3D shape data may only be used within your company. It is strictly prohibited to duplicate (including duplication after partial revision) and provide it to outside third parties.

3. Limitation of liability
�E While TDK-Lambda has taken every precaution to ensure that this site operates properly, the accuracy and utility of these drawings carry no guarantee under law, and TDK-Lambda assumes no legal obligation or liability.
�E The creator is responsible for checking any drawing created using this 3D shape data (including computer graphics images).
�E TDK-Lambda assumes no liability for any problems or losses incurred through the use of this 3D shape data, including any damages or financial losses.

4. Changes, Deletions, Simplifications
�E Note that the contents of this site may be changed or deleted without prior notification.
�E Part of 3D shape data is simplified.

�T. Prior to adoption of TDK-Lambda products, contact us for the "Delivery Specifications".

< Technical Support Contact Information >
�E Switching Power Supply
Fax: +81-120-178090
Email: sps_tech@jp.tdk-lambda.com

�E Noise Filter
Email: nf_tech@jp.tdk-lambda.com

(We regret that these lines are not available from mobile or PHS phones.)

   Copyright (C) 2008 TDK-Lambda Corporation 
